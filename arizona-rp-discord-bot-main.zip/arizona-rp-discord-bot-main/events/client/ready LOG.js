module.exports = async (bot) => {
    console.log(`READY | ${bot.user.username}` + "#" + `${bot.user.discriminator}` + ` запущен.`);
}